"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObservableController = void 0;
/** Small C-owned observable primitive. Master may subscribe and pass fresh props to A. */
class ObservableController {
    listeners = new Set();
    subscribe(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }
    emitChange() {
        for (const listener of [...this.listeners])
            listener();
    }
}
exports.ObservableController = ObservableController;
