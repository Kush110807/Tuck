"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExpoImagePickerAdapter = void 0;
exports.createExpoImagePickerAdapter = createExpoImagePickerAdapter;
const supportedMimeTypes = new Set(['image/jpeg', 'image/png', 'image/webp']);
function failure(code, message) {
    return { kind: 'failed', error: { code, message, field: 'image' } };
}
class ExpoImagePickerAdapter {
    injectedApi;
    constructor(injectedApi) {
        this.injectedApi = injectedApi;
    }
    async pickOne() {
        try {
            const api = this.injectedApi ?? await this.loadApi();
            const permission = await api.requestMediaLibraryPermissionsAsync();
            if (!permission.granted)
                return failure('PERMISSION_DENIED', 'Photo-library permission is required to choose an image.');
            const result = await api.launchImageLibraryAsync({
                mediaTypes: ['images'],
                allowsMultipleSelection: false,
                quality: 1,
            });
            if (result.canceled)
                return { kind: 'cancelled' };
            const asset = result.assets?.[0];
            if (!asset?.uri)
                return failure('PICKER_FAILED', 'The image picker did not return a usable image.');
            if (!asset.mimeType || !supportedMimeTypes.has(asset.mimeType)) {
                return failure('IMAGE_UNSUPPORTED', 'Choose a JPEG, PNG or WebP image.');
            }
            return {
                kind: 'selected',
                selection: {
                    temporaryUri: asset.uri,
                    mimeType: asset.mimeType,
                    ...(typeof asset.fileSize === 'number' ? { reportedBytes: asset.fileSize } : {}),
                },
            };
        }
        catch {
            return failure('PICKER_FAILED', 'The image picker could not be opened.');
        }
    }
    async loadApi() {
        return await Promise.resolve().then(() => __importStar(require('expo-image-picker')));
    }
}
exports.ExpoImagePickerAdapter = ExpoImagePickerAdapter;
function createExpoImagePickerAdapter() {
    return new ExpoImagePickerAdapter();
}
