"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DetailController = void 0;
exports.createDetailController = createDetailController;
const helpers_1 = require("./helpers");
const observable_1 = require("./observable");
class DetailController extends observable_1.ObservableController {
    id;
    origin;
    repository;
    imageStore;
    linkOpener;
    mailbox;
    navigation;
    state = { kind: 'loading' };
    mutation = { kind: 'idle' };
    feedback = null;
    deleteConfirmationOpen = false;
    generation = 0;
    constructor(id, origin, repository, imageStore, linkOpener, mailbox, navigation) {
        super();
        this.id = id;
        this.origin = origin;
        this.repository = repository;
        this.imageStore = imageStore;
        this.linkOpener = linkOpener;
        this.mailbox = mailbox;
        this.navigation = navigation;
    }
    get props() {
        return {
            state: this.state,
            mutation: this.mutation,
            feedback: this.feedback,
            deleteConfirmationOpen: this.deleteConfirmationOpen,
            onOpenLink: () => { void this.openLink(); },
            onEdit: () => this.openEditor(),
            onArchiveOrRestore: () => { void this.archiveOrRestore(); },
            onRequestDelete: () => this.requestDelete(),
            onConfirmDelete: () => { void this.confirmDelete(); },
            onCancelDelete: () => this.cancelDelete(),
            onBack: () => this.back(),
            onRetry: () => { if (!this.isPending())
                void this.refresh(); },
            onDismissFeedback: () => this.dismissFeedback(),
        };
    }
    async refresh() {
        const generation = ++this.generation;
        this.state = { kind: 'loading' };
        this.emitChange();
        try {
            const result = await this.repository.get(this.id);
            if (generation !== this.generation)
                return;
            if (!result.ok) {
                this.state = result.error.code === 'NOT_FOUND' ? { kind: 'missing' } : { kind: 'failed', error: result.error };
                this.emitChange();
                return;
            }
            const image = await (0, helpers_1.resolveImageState)(result.value, this.imageStore);
            if (generation !== this.generation)
                return;
            this.state = image.ok
                ? { kind: 'ready', item: result.value, image: image.value }
                : { kind: 'failed', error: image.error };
            this.emitChange();
        }
        catch {
            if (generation !== this.generation)
                return;
            this.state = { kind: 'failed', error: (0, helpers_1.unexpectedRepositoryError)() };
            this.emitChange();
        }
    }
    async onFocus() {
        const notices = this.mailbox.consume('Detail', this.id);
        if (notices.length > 0) {
            this.feedback = notices[notices.length - 1].feedback;
            this.emitChange();
        }
        await this.refresh();
    }
    readyItem() {
        return this.state.kind === 'ready' ? this.state.item : null;
    }
    isPending() {
        return this.mutation.kind === 'pending';
    }
    back() {
        if (this.isPending())
            return;
        this.navigation.returnToList(this.origin);
    }
    openEditor() {
        if (this.isPending())
            return;
        const item = this.readyItem();
        if (!item)
            return;
        this.navigation.openEditor({ mode: 'edit', id: item.id, origin: this.origin });
    }
    async openLink() {
        if (this.isPending())
            return;
        const item = this.readyItem();
        if (!item || item.type !== 'link')
            return;
        try {
            const result = await this.linkOpener.openHttpUrl(item.url);
            if (!result.ok) {
                this.feedback = { kind: 'error', message: result.error.message };
                this.emitChange();
            }
        }
        catch {
            this.feedback = { kind: 'error', message: 'The link could not be opened.' };
            this.emitChange();
        }
    }
    async archiveOrRestore() {
        if (this.isPending())
            return;
        const item = this.readyItem();
        if (!item)
            return;
        const archived = !item.archived;
        const operation = archived ? 'archive' : 'restore';
        this.mutation = { kind: 'pending', operation };
        this.emitChange();
        let result;
        try {
            result = await this.repository.setArchived(item.id, archived, item.updatedAt);
        }
        catch {
            result = { ok: false, error: (0, helpers_1.unexpectedRepositoryError)() };
        }
        if (!result.ok) {
            this.mutation = { kind: 'failed', operation, error: result.error };
            if (result.error.code === 'CONFLICT') {
                this.feedback = { kind: 'error', message: 'This item changed elsewhere. Review the latest version before trying again.' };
                this.emitChange();
                await this.refreshAfterConflict();
            }
            else {
                this.feedback = { kind: 'error', message: result.error.message };
                this.emitChange();
            }
            return;
        }
        this.mutation = { kind: 'idle' };
        const destination = archived ? 'Inbox' : 'Archive';
        this.mailbox.publish({
            destination,
            operation,
            itemId: result.value.id,
            feedback: { kind: 'success', message: archived ? 'Item archived.' : 'Item restored.' },
        });
        this.emitChange();
        this.navigation.returnToList(destination);
    }
    requestDelete() {
        if (this.isPending() || this.state.kind !== 'ready')
            return;
        this.deleteConfirmationOpen = true;
        this.emitChange();
    }
    cancelDelete() {
        if (this.isPending() || !this.deleteConfirmationOpen)
            return;
        this.deleteConfirmationOpen = false;
        this.emitChange();
    }
    async confirmDelete() {
        if (this.isPending() || !this.deleteConfirmationOpen)
            return;
        const item = this.readyItem();
        if (!item)
            return;
        this.deleteConfirmationOpen = false;
        this.mutation = { kind: 'pending', operation: 'delete' };
        this.emitChange();
        let result;
        try {
            result = await this.repository.remove(item.id, item.updatedAt);
        }
        catch {
            result = { ok: false, error: (0, helpers_1.unexpectedRepositoryError)() };
        }
        if (!result.ok) {
            this.mutation = { kind: 'failed', operation: 'delete', error: result.error };
            if (result.error.code === 'CONFLICT') {
                this.feedback = { kind: 'error', message: 'This item changed elsewhere. Review the latest version before trying again.' };
                this.emitChange();
                await this.refreshAfterConflict();
            }
            else {
                this.feedback = { kind: 'error', message: result.error.message };
                this.emitChange();
            }
            return;
        }
        this.mutation = { kind: 'idle' };
        this.mailbox.publish({
            destination: this.origin,
            operation: 'delete',
            itemId: item.id,
            feedback: { kind: 'success', message: 'Item deleted.' },
        });
        this.emitChange();
        this.navigation.returnToList(this.origin);
    }
    async refreshAfterConflict() {
        const failedMutation = this.mutation;
        await this.refresh();
        this.mutation = failedMutation;
        this.emitChange();
    }
    dismissFeedback() {
        if (this.feedback === null)
            return;
        this.feedback = null;
        this.emitChange();
    }
}
exports.DetailController = DetailController;
function createDetailController(id, origin, repository, imageStore, linkOpener, mailbox, navigation) {
    return new DetailController(id, origin, repository, imageStore, linkOpener, mailbox, navigation);
}
