"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unexpectedRepositoryError = unexpectedRepositoryError;
exports.normalizeTagDisplay = normalizeTagDisplay;
exports.tagKey = tagKey;
exports.collectAvailableTags = collectAvailableTags;
exports.resolveImageState = resolveImageState;
exports.buildListRows = buildListRows;
const domain_1 = require("../domain");
function unexpectedRepositoryError(message = 'The local item store could not be reached.') {
    return { code: 'DB_FAILED', message };
}
function normalizeTagDisplay(value) {
    return (0, domain_1.normalizeComparableText)(value);
}
function tagKey(value) {
    return (0, domain_1.toComparisonKey)(value);
}
function collectAvailableTags(items) {
    const seen = new Set();
    const result = [];
    for (const item of items) {
        for (const tag of item.tags) {
            const display = normalizeTagDisplay(tag);
            const key = tagKey(display);
            if (!display || seen.has(key))
                continue;
            seen.add(key);
            result.push(display);
        }
    }
    return result;
}
async function resolveImageState(item, imageStore, degradeResolutionFailureToMissing = false) {
    if (item.type !== 'image')
        return { ok: true, value: { kind: 'none' } };
    try {
        const result = await imageStore.resolve(item.imagePath);
        if (!result.ok) {
            if (degradeResolutionFailureToMissing)
                return { ok: true, value: { kind: 'missing' } };
            return result;
        }
        return result.value.kind === 'available'
            ? { ok: true, value: { kind: 'available', uri: result.value.uri } }
            : { ok: true, value: { kind: 'missing' } };
    }
    catch {
        const error = { code: 'INVALID_IMAGE_PATH', message: 'The saved image could not be resolved.' };
        return degradeResolutionFailureToMissing ? { ok: true, value: { kind: 'missing' } } : { ok: false, error };
    }
}
async function buildListRows(items, imageStore) {
    return Promise.all(items.map(async (item) => {
        const image = await resolveImageState(item, imageStore, true);
        return { item, image: image.ok ? image.value : { kind: 'missing' } };
    }));
}
