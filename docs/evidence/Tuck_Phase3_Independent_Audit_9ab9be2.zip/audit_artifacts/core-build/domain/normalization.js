"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeComparableText = normalizeComparableText;
exports.toComparisonKey = toComparisonKey;
exports.normalizeTags = normalizeTags;
const INTERNAL_WHITESPACE = /\s+/gu;
/** Normalization shared by tag storage, tag comparison, and free-text search. */
function normalizeComparableText(value) {
    return value.normalize('NFKC').trim().replace(INTERNAL_WHITESPACE, ' ');
}
function toComparisonKey(value) {
    return normalizeComparableText(value).toLowerCase();
}
/**
 * Empty tags are ignored and duplicate comparison keys keep the first
 * normalized display spelling, exactly as required by CONTRACT_RULES.md.
 */
function normalizeTags(values) {
    const seen = new Set();
    const tags = [];
    for (const raw of values) {
        const display = normalizeComparableText(raw);
        if (!display)
            continue;
        const key = display.toLowerCase();
        if (seen.has(key))
            continue;
        seen.add(key);
        tags.push({ key, display });
    }
    return tags;
}
