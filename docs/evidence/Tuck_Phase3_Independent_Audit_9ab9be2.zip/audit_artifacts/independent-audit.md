# Tuck — Phase 3 Independent Audit

**Audit date:** 28 September 2026 (IST)  
**Role:** Independent reviewer; no app repairs or redesign performed.  
**Candidate audited:** `Tuck_Phase2_Integrated_Candidate_9ab9be2(2).zip` (uploaded copy of the named Phase 2 candidate)  
**Expected / verified Git HEAD:** `9ab9be28d70c66235a2aabd287b87ed5c1c9a568`  
**Expected / verified ZIP SHA-256:** `ae44024f18710ad9e65396c0bf7a370f64342e0e1f9e6ad3dfb8440a7d0e22d2`  
**Baseline ancestor:** `1af6a69f6638e3c2fd26319efd253084e24760e0` — verified ancestor.  
**Candidate mutation policy:** The extracted candidate was treated read-only. Install attempts were performed in a separate Git clone and audit tests/reports were created outside the candidate tree.

## 1. Executive result

**Phase 3 outcome: FAIL — repairs are required before this candidate should be called release/submission ready.**

This is not a claim that Stage 1 is broadly broken. The architecture and most controller/repository flows are coherent, and several difficult integration risks were handled correctly. The audit nevertheless confirms source-level defects in startup cleanup handling, image metadata availability, and image-picker/image-validation behavior, plus a smaller stale-edit navigation deviation. Canonical dependency-backed verification and all physical Android visual/relaunch checks also remain blocked/not run.

Confirmed findings:

| ID | Severity | Finding | Evidence basis |
|---|---|---|---|
| P3-01 | **High** | A non-fatal image-reconciliation/enumeration failure can become blocking `INIT_FAILED`, making all metadata unavailable at startup. | Concrete source execution path: `SQLiteItemRepository.initialize()` lines 197–219; `reconcileUnreferencedImages()` lines 616–638; `PersistentImageStore.listOwnedRelativePaths()` lines 131–147; BootGate blocks navigator. |
| P3-02 | **Medium** | Detail and edit Editor hide item metadata when image resolution returns an error other than ordinary `missing`. | Independently executed controller harness + source: `resolveImageState()` default does not degrade failures; Detail lines 56–73; Editor lines 492–510. |
| P3-03 | **Medium** | Image selection is hard-gated on photo-library permission even though current Expo docs say library launch itself does not require that permission (except the documented old iOS condition). A denial prevents the picker from launching. | Source `expoImagePickerAdapter.ts` lines 25–35 + official Expo ImagePicker docs. |
| P3-04 | **Medium** | Image validation does not verify the actual file format/decodability. It trusts picker MIME metadata to choose an extension, checks existence/size, and treats any existing stored file as renderable; valid assets with unavailable MIME metadata are also rejected. | Source `PersistentImageStore.ts` lines 50–114 and picker adapter lines 38–49; Expo documents `mimeType` may be unavailable. No React Native `Image.onError` converts corrupt/unreadable rendering to `missing`. |
| P3-05 | **Low** | A missing edit target remains on an Editor missing screen and requires user action, instead of the specified automatic safe return to Inbox with feedback. | Independently executed controller harness + `editorController.ts` lines 131–149; Phase 0 navigation rule. |
| P3-06 | **Low** | With an active tag filter, a later search/type change yielding zero rows removes the tag selector entirely, so the selected tag is no longer visible or individually clearable; only the global “Clear filters” recovery remains. | Concrete UI/data path: list `availableTags` is derived from already-filtered results; `FilterBar` renders tags only when non-empty. |

No defect was confirmed for the specifically requested **second-conflict-before-overwrite** case: an independent executable controller scenario produced expected timestamps `100 → 200 → 300`, preserved the local draft through both conflicts, required a second explicit confirmation, and navigated only after the third successful write.

## 2. Review basis and provenance

### 2.1 Integrity / Git

| Check | Result | Evidence |
|---|---|---|
| ZIP SHA-256 | **PASS** | Exact expected digest. |
| Embedded Git HEAD | **PASS** | Exact expected SHA. |
| Clean worktree before audit | **PASS** | `git status --short` empty. |
| Baseline ancestor | **PASS** | `git merge-base --is-ancestor … HEAD` exit 0. |
| Git object integrity | **PASS** | `git fsck --no-progress --full` exit 0. |
| `git diff --check` | **PASS** | Exit 0. |
| Candidate unchanged after audit | **PASS** | Final `git status --short` remains empty. |

The meaningful history contains separate A/B/C integration commits before master integration, matching the handoff claim.

### 2.2 Documents read

Reviewed `README.md`, `docs/CONTRACT_RULES.md`, `docs/architecture.md`, `docs/integration-changelog.md`, `docs/phase2-verification.md`, `docs/qa-plan.md`, `docs/release.md`, `docs/phase3-reviewer-handoff.md`, the shared contracts, production code, tests, and Phase 0 v2.

Documented Phase 2 amendments were accepted where explicitly recorded (notably typed list rows and the explicit edit-conflict confirmation state/callbacks). They were not used to silently waive contradictory Phase 0 behavior. Two unresolved contradictions matter to findings: (a) safe cleanup is documented as non-fatal/queued, while some startup cleanup/reconciliation errors are fatal; (b) Phase 0 says a disappeared edit target returns safely to Inbox with feedback, while the integrated code deliberately exposes a missing Editor state.

### 2.3 Production graph / hygiene

- `App.tsx` constructs one shared `createTuckDataLayer()`, one mailbox, picker/link adapters, and BootController.
- The navigator mounts only after successful initialization.
- Production wiring uses `SQLiteItemRepository` + `PersistentImageStore`; preview/fixture modules are not imported by the production graph.
- `src/ui/**` has no direct SQLite/FileSystem/ImagePicker/React Navigation/browser calls in the audit grep.
- No tracked `node_modules`, generated native folders, build outputs, keystores or obvious `.env` material were found.

## 3. Reproducible project verification

Environment observed: Node `v22.16.0`, npm `10.9.2`, global TypeScript `5.8.3`, Python `3.13.5`.

### 3.1 Clean install and canonical commands

A disposable verification clone at the exact audited SHA was used. One bounded online `npm ci --ignore-scripts --no-audit --no-fund` attempt encountered repeated npm-registry DNS `EAI_AGAIN` failures. The required `zod-3.25.76.tgz` and many other tarballs could not be fetched. The audit did not repeat the same network attempt.

A subsequent offline-only `npm ci` failed immediately with `ENOTCACHED` for `zod-3.25.76.tgz`. Therefore the committed dependency tree was not installed.

| Command | Audit result | Interpretation |
|---|---|---|
| `npm ci` | **BLOCKED — NETWORK/CACHE** | Online registry resolution produced repeated `EAI_AGAIN`; offline cache lacks required tarballs. Not a code failure. |
| `npm run typecheck` | **BLOCKED** | Command was invoked after failed install; it reported absent `expo/tsconfig.base` and Node/React/RN typings. Because committed dependencies are absent and the shell used a global compiler, this is not classified as a project compile failure. |
| `npm test` | **BLOCKED** | `vitest: not found`. |
| `npm run export:android` | **BLOCKED** | `expo: not found`. |
| `npx --offline expo install --check` | **BLOCKED** | Expo package not cached. |

The Phase 2 blocker claim is independently reproduced.

### 3.2 Supplemental dependency-free TypeScript check

A separate audit-only compilation of production contracts/domain/core Editor+Detail controller files passed with the system TypeScript compiler. This is useful source evidence only; it is **not** a replacement for the canonical project typecheck and is not counted as one.

Attempting to add the real ImagePicker adapter to this supplemental compile correctly failed because `expo-image-picker` typings were not installed; no typing stubs were introduced to force a pass.

### 3.3 Package/native API compatibility review

The lockfile resolves the major runtime packages consistently with `package.json`, including Expo `57.0.25`, React Native `0.86.3`, React `19.2.3`, `expo-sqlite 57.0.3`, `expo-file-system 57.0.7`, `expo-image-picker 57.0.20`, `expo-status-bar 57.0.1`, `react-native-screens 4.26.2`, and `react-native-safe-area-context 5.7.0`.

Official Expo documentation currently maps SDK 57 to React Native 0.86 / React 19.2.3 / Node 22.13.x minimum and recommends the exact SQLite/FileSystem/ImagePicker/StatusBar package lines used here. React Navigation's documented minimums are below this candidate's RN/Expo versions, and the lockfile peer dependencies are internally satisfied. **Source-level version compatibility: PASS.** The blocked `expo install --check` means Expo CLI's own dependency validation remains unexecuted.

The use of `withExclusiveTransactionAsync(async tx => …)` is aligned with Expo SQLite's transaction API: transactional queries must use the supplied transaction object. Source inspection confirms the candidate does so for multi-table mutation blocks.

## 4. User journey audit

Legend: **PASS (source)** means the data/control path was traced and no defect was found, not that a phone journey ran. **FAIL** means a concrete defect was reproduced or established by a concrete source execution path. **NOT RUN** means the requested evidence requires unavailable installed/native rendering/device execution.

| Journey / requirement | Result | Notes |
|---|---|---|
| Boot loading/failure/retry | **FAIL** | Boot state/UI itself is sound, but P3-01 can turn safe image-reconciliation failure into total startup failure. |
| Create note | **PASS (source); DEVICE NOT RUN** | Validation → repository create → mailbox → Detail path traced; duplicate Save guard is synchronous. |
| Create link | **PASS (source); DEVICE NOT RUN** | HTTP(S)-only validation and external-open error feedback traced. |
| Create image | **FAIL** | P3-03/P3-04 affect picker access/metadata/actual format assurance. Copy-before-DB order otherwise sound. |
| View note/link | **PASS (source); DEVICE NOT RUN** | Normal Detail path coherent. |
| View image | **FAIL** | Ordinary missing file is handled; non-missing resolve error hides metadata (P3-02); corrupt rendering has no fallback (P3-04). |
| Edit note/link | **PASS (source); DEVICE NOT RUN** | Draft, validation/storage failure retention, optimistic conflict behavior traced. |
| Edit image | **FAIL** | Same image-resolution/validation issues as above. |
| Second conflict before overwrite confirmation | **PASS — independently executed** | Second stale write is rejected; draft remains; second confirmation required. |
| Tags + normalization | **PASS (source)** | NFKC, whitespace collapse, lower comparison key, dedupe, max counts/lengths implemented. |
| Search/type/tag/archive AND semantics | **PASS (source)** | Repository validates query, filters with normalized per-field substring semantics and archive/type/tag AND rules. |
| Stable sort | **PASS (source + real SQLite support)** | `updatedAt DESC, id ASC`; real-SQLite check confirmed equal-timestamp ID order. |
| Filter usability / no matches | **PARTIAL FAIL** | “Clear filters” recovers, but active tag visibility is lost in zero-row state (P3-06). |
| Archive | **PASS (source); DEVICE NOT RUN** | Pending guard, expected timestamp, destination Inbox, mailbox + focus refresh traced. |
| Restore | **PASS (source); DEVICE NOT RUN** | Same; destination Archive. |
| Delete confirmation | **PASS (source); DEVICE NOT RUN** | Explicit confirmation + duplicate guard + optimistic timestamp checked. |
| Missing Detail ID | **PASS (source)** | Missing state displayed and Back available. |
| Missing edit ID | **FAIL** | P3-05: missing state remains in Editor instead of specified auto-return + feedback. |
| Missing image file | **PASS for ordinary nonexistence** | `resolve()` returns `missing`; list/detail/editor metadata remains available. |
| Other image-resolution failure | **FAIL** | P3-02. |
| Picker cancellation | **PASS (source)** | Leaves draft unchanged. |
| Picker failure/denial | **PARTIAL FAIL** | Failure leaves draft, but denial is unnecessarily required as a precondition (P3-03). |
| External-link failure | **PASS (source)** | Feedback only; data unchanged. |
| Draft after validation/storage error | **PASS (source)** | Current ready draft is retained in mutation failure handling. |
| Duplicate Save | **PASS (source + supplied test design)** | Pending set before await. |
| Duplicate archive/delete | **PASS (source + supplied test design)** | Pending set before await. |
| Dirty Cancel / Android Back | **PASS (source); DEVICE NOT RUN** | Dirty prompt wired; pending mutation blocks exit; gestures disabled. |
| Relaunch persistence | **NOT RUN** | SQLite/file APIs are designed for persistent storage, but no installed-app relaunch evidence exists. |
| Airplane-mode local CRUD | **NOT RUN** | No network dependency is present in local repository flow, but native device execution was not possible. |

## 5. Targeted integration-risk review

### 5.1 `useControllerProps` render/subscription timing

`useControllerProps()` reads props during render and subscribes in a passive `useEffect`. In the abstract, a controller emission between render and effect subscription would not itself schedule a rerender. In the actual production routes, however, controller-starting focus/load effects are registered after `useControllerProps`, stable controllers are created with `useMemo`, and subscription cleanup is returned by `ObservableController.subscribe()`. I found no concrete production path that demonstrably loses a required update. **No defect reported.** A real React lifecycle test remains unavailable because dependencies did not install.

### 5.2 Stable controllers / focus / async results

- Inbox/Archive/Detail controller instances are `useMemo`-stable for route/service identity.
- Focus refresh is present for Inbox/Archive/Detail.
- Editor load and list/detail image resolution use generation guards for stale async results.
- Pending mutation guards prevent navigation races for save/archive/delete.
- Subscriptions are cleaned up.

No confirmed late-result/navigation defect was found. Android-native lifecycle behavior remains device-not-run.

### 5.3 MutationMailbox

Mailbox consumption is destination-specific and destructive (one-shot). Detail notices are also item-specific. Lists refresh on every focus, so cross-list freshness does not rely solely on receiving feedback. **PASS (source).** Existing banner state persists until the user dismisses it; this can leave an old success banner visible after a later cross-list mutation, but the specification does not require automatic expiry, so this audit does not classify that as a defect.

### 5.4 Edit conflicts

**PASS.** The controller does not automatically rebase/write after a conflict. It stores the latest item only as an overwrite baseline, preserves the local draft, and writes after explicit confirmation. The independent audit harness confirms a second intervening change causes another conflict and another confirmation rather than a stale overwrite.

### 5.5 List filters

Core query correctness passes source review. Recovery from no matches exists through “Clear filters.” P3-06 is a smaller usability issue: `availableTags` is derived from the already-filtered result, so a selected tag can disappear from the control when another criterion yields zero items.

### 5.6 SQLite initialization and cleanup

Normal DB open/migration failure is correctly fatal. Failed physical deletion of a queued image is correctly treated as safe: the queue row stays and initialization can continue.

**P3-01:** other cleanup/reconciliation failures are not consistently treated as safe. `initialize()` directly converts any error from `retryPendingFileCleanupUnsafe()` or `reconcileUnreferencedImages()` to `INIT_FAILED`. In particular, `PersistentImageStore.listOwnedRelativePaths()` returns an error if directory enumeration fails; `reconcileUnreferencedImages()` propagates it; initialization then fails and the navigator never mounts. This makes notes/links/existing metadata unavailable because optional cleanup inspection failed. That conflicts with the integrated rule that safe cleanup failures stay queued/retry later.

A database failure while reading cleanup/reference tables is harder to categorize and may legitimately signal DB corruption. The defect classification here is specifically the file-storage enumeration/cleanup side that is not required to read metadata.

### 5.7 Image operation ordering / path containment

Path containment uses a narrow `images/<safe-name>.(jpg|jpeg|png|webp)` form and rejects traversal/backslash/query/hash/percent patterns. Copy-before-commit, replacement queue-before-old-delete, delete queue-before-file-delete, and best-effort orphan cleanup are structurally correct.

The supplied image-order tests mock `expo-sqlite`; their transaction helper snapshots only the in-memory pending-path set and does not provide a real SQLite engine. They are still useful for verifying the candidate calls operations in the intended order, but cannot prove SQL constraints, foreign keys, transaction implementation, native commit timing, or persistence. The independent real-SQLite audit covered the schema/ordinary transaction semantics separately and passed.

### 5.8 Image validation/rendering

Actual size is rechecked through `File.size` before commit: **PASS (source)**.

Actual format/decodability is not rechecked: **FAIL (P3-04)**. The store chooses the output extension solely from `selection.mimeType`, copies the bytes, checks destination existence/size, and `resolve()` only checks path safety + existence. React Native image components have no `onError` handler that can downgrade a decoding failure to `missing`. Thus corrupt/non-image bytes labeled with a supported MIME value can be persisted and then represented as “available”; conversely, Expo-documented valid picker results with unavailable MIME metadata are rejected before the store can inspect them.

## 6. Test quality

### 6.1 What supplied tests do prove (if/when Vitest runs)

The test design meaningfully targets:
- domain normalization/limits;
- dirty/discard state;
- picker cancellation;
- duplicate save/archive/delete guards;
- first edit conflict and explicit confirmation;
- stale list response suppression;
- missing-file metadata path;
- mailbox routing/focus refresh;
- image copy/queue/delete call order;
- failed replacement cleanup;
- queued deletion retry when `removeFile` itself fails.

### 6.2 What supplied tests do **not** prove

They do not prove:
- React render/effect subscription timing;
- React Navigation/native-stack behavior;
- Expo SQLite native transaction/persistence semantics;
- Expo FileSystem behavior and actual Android paths;
- real ImagePicker permissions/content-provider variants;
- Android process death during picker;
- force-close/relaunch persistence;
- visual layout, keyboard, accessibility service behavior, or screen-reader output.

The SQLite tests explicitly mock both `expo-sqlite` and `expo-file-system`. The image-order transaction mock manually restores only its pending-set snapshot on exception. That can conceal differences between the fake state model and real SQLite, so these tests are evidence of intended JS call sequence, not native transaction proof.

### 6.3 Independent audit tests

**Executed:**
1. `audit-core-scenarios.js` — second conflict, Detail image-resolution failure, stale edit target.
2. `real_sqlite_audit.py` — candidate schema on real SQLite, row CHECKs, FK cascade, deterministic sort tie, rollback/commit of metadata + cleanup queue.

**Not executed because dependency installation is blocked:** a React lifecycle test for `useControllerProps`, Vitest reproduction of startup directory-enumeration failure using the repository module, and native Expo storage/picker tests.

## 7. UI / accessibility review

### 7.1 Source-level positives

- Shared minimum touch size is `44`; ActionButton, tag/type chips, search clear affordance, feedback dismiss, and tag remove controls use it.
- Interactive controls generally set accessibility role/label/state.
- Error/status containers use live regions and alert roles where applicable.
- Core layouts use wrapping rows and vertical ScrollViews rather than hard fixed widths.
- Text does not globally disable font scaling.
- Color contrast of the declared primary text, secondary text, primary action and error colors against their normal backgrounds is acceptable in a simple static contrast calculation (secondary text on app background ~5.45:1; primary action on white ~9.32:1; error on white ~7.05:1).

### 7.2 Limits / NOT RUN

**Rendered visual verification is NOT RUN.** Dependency installation failed, no native build/APK exists, and no device screenshots/results were supplied. Therefore narrow-screen clipping, keyboard obstruction, large-font reflow, modal focus behavior, TalkBack reading order, real 44 dp hit areas, image scaling, status announcements and physical touch behavior remain unverified.

One source-level usability concern is P3-06 (selected tag visibility in zero matches). Form text fields also remain visually editable during a pending Save even though controller callbacks ignore changes; buttons/tag input are disabled. This audit records that as a UX observation rather than a separate release defect because mutation integrity is still guarded.

## 8. Official API observations relevant to findings

- Expo SDK 57 officially targets RN 0.86 / React 19.2.3 / Node 22.13.x minimum; Android support starts at Android 7 with compile/target SDK 36.
- Current Expo docs recommend `expo-sqlite ~57.0.3`, `expo-file-system ~57.0.7`, `expo-image-picker ~57.0.20`, and `expo-status-bar ~57.0.1`, matching the project lines.
- Expo ImagePicker states that no permission request is necessary simply to launch the image library and documents `launchImageLibraryAsync()` as requiring media-library permission only on iOS 10 in that API description.
- Expo documents `ImagePickerAsset.mimeType` as optional / possibly unavailable and notes some Android providers may not determine media type.
- Expo documents `getPendingResultAsync()` because Android can kill `MainActivity` after the picker finishes. The candidate does not call it. Because Phase 0 does not explicitly require recovery of a picker result across Android activity destruction, this is recorded as a **native-lifecycle coverage risk**, not an additional confirmed Stage 1 defect. It should be included in phone QA, especially with Android “Don’t keep activities.”

## 9. Release/readiness matrix

| Gate | Phase 3 result |
|---|---|
| Candidate identity / history | **PASS** |
| Source architecture / production wiring | **PASS with defects listed above** |
| Package version source compatibility | **PASS** |
| Fresh `npm ci` | **BLOCKED — environment/network** |
| Canonical TypeScript | **BLOCKED** |
| Repository Vitest suite | **BLOCKED** |
| Expo Android JS export | **BLOCKED** |
| `expo install --check` | **BLOCKED** |
| Real-SQLite schema/transaction semantics | **PASS (supplemental, non-Expo)** |
| Independent second-conflict test | **PASS** |
| Physical Android launch | **NOT RUN** |
| APK build/install | **NOT RUN** |
| Force-close/relaunch persistence | **NOT RUN** |
| Airplane-mode device CRUD | **NOT RUN** |
| Narrow-screen / keyboard / large text / TalkBack | **NOT RUN** |
| Phase 3 defect-free release gate | **FAIL** |

## 10. Required Phase 4 targets (no repairs performed here)

The next repair phase should address and retest, without broad redesign:

1. Separate fatal DB initialization from noncritical image cleanup/reconciliation failures so safe file cleanup cannot block access to metadata.
2. Keep Detail/Editor metadata usable when image resolution fails for reasons other than a simple nonexistent file; provide a degraded image state instead of replacing the whole screen with failure where safe.
3. Align the image-picker adapter with Expo’s current library-launch permission model and handle valid assets whose MIME metadata is absent without silently accepting unsupported bytes.
4. Validate actual image format/decodability or otherwise handle decode failure explicitly so corrupt/non-image bytes cannot remain an “available” image with no recovery UI.
5. Resolve the stale edit-target behavior/document contradiction: implement the specified return+feedback or formally amend the requirement before claiming conformance.
6. Keep the active tag filter visible/recoverable when the current result is empty.
7. After repairs, successfully install the lockfile, run canonical commands, build/run on the physical Android phone, and execute the entire `docs/qa-plan.md`, including Android activity-destruction picker recovery as an added stress check.

Any repair creates a new candidate SHA and invalidates the unqualified Phase 3 result for the old SHA; retest the changed paths and adjacent journeys on that new exact build.
