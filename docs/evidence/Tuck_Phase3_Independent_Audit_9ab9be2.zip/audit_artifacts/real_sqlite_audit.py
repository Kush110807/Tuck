import sqlite3, json

SCHEMA = r'''
CREATE TABLE items (
 id TEXT PRIMARY KEY NOT NULL,
 type TEXT NOT NULL CHECK (type IN ('note','link','image')),
 title TEXT NOT NULL,
 body TEXT,
 url TEXT,
 image_path TEXT,
 created_at INTEGER NOT NULL,
 updated_at INTEGER NOT NULL,
 archived INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0,1)),
 CHECK (
  (type='note' AND body IS NOT NULL AND url IS NULL AND image_path IS NULL) OR
  (type='link' AND body IS NULL AND url IS NOT NULL AND image_path IS NULL) OR
  (type='image' AND url IS NULL AND image_path IS NOT NULL)
 )
);
CREATE TABLE item_tags (
 item_id TEXT NOT NULL REFERENCES items(id) ON DELETE CASCADE,
 tag_key TEXT NOT NULL,
 display TEXT NOT NULL,
 ordinal INTEGER NOT NULL,
 PRIMARY KEY(item_id,tag_key), UNIQUE(item_id,ordinal)
);
CREATE TABLE pending_file_deletions(path TEXT PRIMARY KEY NOT NULL, queued_at INTEGER NOT NULL);
CREATE INDEX idx_items_archive_type_updated ON items(archived,type,updated_at DESC,id ASC);
CREATE INDEX idx_item_tags_key ON item_tags(tag_key,item_id);
'''

def expect_integrity_error(conn, sql, params):
    try:
        conn.execute(sql, params)
    except sqlite3.IntegrityError:
        return True
    raise AssertionError('expected sqlite3.IntegrityError')

conn = sqlite3.connect(':memory:')
conn.execute('PRAGMA foreign_keys = ON')
conn.executescript(SCHEMA)

# Valid rows and deterministic order at equal timestamps.
conn.execute("INSERT INTO items VALUES (?,?,?,?,?,?,?,?,?)", ('b','note','B','body',None,None,1,10,0))
conn.execute("INSERT INTO items VALUES (?,?,?,?,?,?,?,?,?)", ('a','note','A','body',None,None,1,10,0))
conn.execute("INSERT INTO item_tags VALUES (?,?,?,?)", ('a','work','Work',0))
order = [r[0] for r in conn.execute("SELECT id FROM items WHERE archived=0 ORDER BY updated_at DESC,id ASC")]
assert order == ['a','b'], order

# Discriminated storage constraints reject malformed records.
invalid_note = expect_integrity_error(conn,
    "INSERT INTO items VALUES (?,?,?,?,?,?,?,?,?)",
    ('bad-note','note','Bad',None,None,None,1,1,0))
invalid_link = expect_integrity_error(conn,
    "INSERT INTO items VALUES (?,?,?,?,?,?,?,?,?)",
    ('bad-link','link','Bad',None,None,None,1,1,0))
invalid_image = expect_integrity_error(conn,
    "INSERT INTO items VALUES (?,?,?,?,?,?,?,?,?)",
    ('bad-image','image','Bad',None,None,None,1,1,0))

# Foreign-key cascade is real SQLite behavior, not a mock assumption.
conn.execute("DELETE FROM items WHERE id='a'")
assert conn.execute("SELECT COUNT(*) FROM item_tags WHERE item_id='a'").fetchone()[0] == 0

# Transaction rollback: queue insertion + metadata update roll back together if a later step fails.
conn.execute("INSERT INTO items VALUES (?,?,?,?,?,?,?,?,?)", ('img','image','Photo','cap',None,'images/old.jpg',1,20,0))
conn.commit()
try:
    conn.execute('BEGIN')
    conn.execute("INSERT INTO pending_file_deletions(path,queued_at) VALUES (?,?)", ('images/old.jpg',99))
    conn.execute("UPDATE items SET image_path=?, updated_at=? WHERE id='img'", ('images/new.jpg',21))
    raise RuntimeError('forced transaction failure')
except RuntimeError:
    conn.rollback()
row = conn.execute("SELECT image_path,updated_at FROM items WHERE id='img'").fetchone()
queued = conn.execute("SELECT COUNT(*) FROM pending_file_deletions WHERE path='images/old.jpg'").fetchone()[0]
assert row == ('images/old.jpg',20), row
assert queued == 0, queued

# Successful atomic metadata+queue commit persists together.
with conn:
    conn.execute("INSERT INTO pending_file_deletions(path,queued_at) VALUES (?,?)", ('images/old.jpg',100))
    conn.execute("UPDATE items SET image_path=?, updated_at=? WHERE id='img'", ('images/new.jpg',21))
row2 = conn.execute("SELECT image_path,updated_at FROM items WHERE id='img'").fetchone()
queued2 = conn.execute("SELECT COUNT(*) FROM pending_file_deletions WHERE path='images/old.jpg'").fetchone()[0]
assert row2 == ('images/new.jpg',21)
assert queued2 == 1

result = {
  'engine': sqlite3.sqlite_version,
  'schema_executes': True,
  'discriminated_checks_reject_invalid_rows': invalid_note and invalid_link and invalid_image,
  'foreign_key_cascade': True,
  'deterministic_equal_timestamp_order': order,
  'real_transaction_rollback_metadata_and_queue': True,
  'real_transaction_commit_metadata_and_queue': True,
  'scope_note': 'This validates ordinary SQLite semantics for the candidate schema. It does not validate expo-sqlite native bindings or device persistence.'
}
print(json.dumps(result, indent=2))
