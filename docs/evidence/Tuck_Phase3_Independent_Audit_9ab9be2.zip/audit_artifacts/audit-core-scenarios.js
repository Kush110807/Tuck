const assert = require('assert');
const { EditorController } = require('./core-build/controllers/editorController.js');
const { DetailController } = require('./core-build/controllers/detailController.js');

const base = {
  id: 'n1', type: 'note', title: 'Original', body: 'Body', url: null, imagePath: null,
  tags: ['work'], createdAt: 100, updatedAt: 100, archived: false,
};
const imageItem = {
  id: 'i1', type: 'image', title: 'Photo', body: 'Caption', url: null, imagePath: 'images/a.jpg',
  tags: ['photo'], createdAt: 100, updatedAt: 100, archived: false,
};
const ok = value => ({ok:true, value});
const err = (code, message='error') => ({ok:false, error:{code, message}});
const flush = () => new Promise(r => setTimeout(r, 0));

function emptyRepo() {
  return {
    initialize: async () => ok(undefined), list: async () => ok([]), get: async () => err('NOT_FOUND'),
    create: async () => err('DB_FAILED'), update: async () => err('DB_FAILED'),
    setArchived: async () => err('DB_FAILED'), remove: async () => err('DB_FAILED'),
    retryPendingFileCleanup: async () => ok({remaining:0}),
  };
}
function imageStore(resolveImpl = async () => ok({kind:'missing'})) {
  return { copySelected: async () => err('IMAGE_COPY_FAILED'), resolve: resolveImpl, removeFile: async () => ok(undefined) };
}
function picker() { return {pickOne: async () => ({kind:'cancelled'})}; }
function mailbox() { return {events:[], publish(n){this.events.push(n); return {...n,sequence:this.events.length}}, consume(){return []}}; }
function navigation() { return {calls:[], showDetail(...a){this.calls.push(['showDetail',...a])}, completeCreate(...a){this.calls.push(['completeCreate',...a])}, completeEdit(...a){this.calls.push(['completeEdit',...a])}, returnToList(...a){this.calls.push(['returnToList',...a])}, openEditor(...a){this.calls.push(['openEditor',...a])}, openArchive(...a){this.calls.push(['openArchive',...a])}, goBackOrInbox(...a){this.calls.push(['goBackOrInbox',...a])}}; }

async function secondConflictScenario() {
  const repo = emptyRepo();
  const latest1 = {...base, body:'remote-1', updatedAt:200};
  const latest2 = {...base, body:'remote-2', updatedAt:300};
  let gets = 0;
  repo.get = async () => ok([base, latest1, latest2][Math.min(gets++,2)]);
  const expectedTimes = [];
  let updates = 0;
  repo.update = async input => {
    expectedTimes.push(input.expectedUpdatedAt);
    updates += 1;
    if (updates <= 2) return err('CONFLICT', 'stale');
    return ok({...latest2, title: input.changes.title ?? latest2.title, updatedAt:301});
  };
  const nav = navigation(); const mb = mailbox();
  const c = new EditorController({mode:'edit',id:base.id,origin:'Inbox'}, repo, imageStore(), picker(), mb, nav);
  await c.load();
  c.props.onTitleChange('My local draft');
  c.props.onSave(); await flush(); await flush();
  assert.equal(c.props.state.kind,'ready');
  assert.equal(c.props.state.conflictConfirmationOpen,true);
  assert.equal(c.props.state.draft.title,'My local draft');
  assert.equal(updates,1);
  c.props.onConfirmConflictOverwrite(); await flush(); await flush();
  assert.equal(c.props.state.kind,'ready');
  assert.equal(c.props.state.conflictConfirmationOpen,true, 'second conflict must require a second explicit confirmation');
  assert.equal(c.props.state.draft.title,'My local draft');
  assert.equal(updates,2);
  assert.equal(nav.calls.length,0);
  c.props.onConfirmConflictOverwrite(); await flush(); await flush();
  assert.deepEqual(expectedTimes,[100,200,300]);
  assert.equal(updates,3);
  assert.deepEqual(nav.calls.at(-1),['completeEdit','n1','Inbox']);
  return {expectedTimes, draftPreserved:true, secondConfirmationRequired:true};
}

async function detailResolutionFailureScenario() {
  const repo = emptyRepo(); repo.get = async () => ok(imageItem);
  const c = new DetailController(imageItem.id,'Inbox',repo,imageStore(async () => err('OPEN_FAILED','fs read failure')),
    {openHttpUrl:async()=>ok(undefined)},mailbox(),navigation());
  await c.refresh();
  assert.deepEqual(c.props.state,{kind:'failed',error:{code:'OPEN_FAILED',message:'fs read failure'}});
  return c.props.state;
}

async function staleEditScenario() {
  const repo = emptyRepo();
  const nav = navigation();
  const c = new EditorController({mode:'edit',id:'gone',origin:'Archive'},repo,imageStore(),picker(),mailbox(),nav);
  await c.load();
  assert.deepEqual(c.props.state,{kind:'missing'});
  assert.equal(nav.calls.length,0, 'controller does not automatically return to Inbox');
  return {state:c.props.state,navigationCalls:nav.calls};
}

(async () => {
  const result = {
    secondConflict: await secondConflictScenario(),
    detailImageResolutionFailure: await detailResolutionFailureScenario(),
    staleEdit: await staleEditScenario(),
  };
  console.log(JSON.stringify(result,null,2));
})().catch(e => { console.error(e); process.exit(1); });
